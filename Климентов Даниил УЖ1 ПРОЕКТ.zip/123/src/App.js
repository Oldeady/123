import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";
import ProductList from "./components/ProductList";
import Feedback from "./components/Feedback";
import About from "./components/About";
import News from "./components/News";
import CreateProductForm from "./components/CreateProductForm";
import { FaTelegram } from "react-icons/fa";
import { Product } from "./components/Product";
import NavMenu from "./components/NavMenu";
import Banner from "./components/Banner";
import ProductTable from "./components/ProductTable";
import EditProductForm from "./components/EditProductFrom";
import logo from "./assets/logo.svg";

function App() {
  return (
    <BrowserRouter>
      <div className="main-container">
        <header>
          <div className="logo">
            <img
              src={logo}
              alt="logo"
            />
          </div>
        </header>
        <main>
          <section>
            <NavMenu />
          </section>
          <article>
            <Routes>
              <Route path="/" element={<ProductList />} />
              <Route path="/news" element={<News />} />
              <Route path="/about" element={<About />} />
              <Route path="/products" element={<ProductList />} />
              <Route path="/product-table" element={<ProductTable />} />
              <Route path="/product/:id" element={<Product />} />
              <Route path="/product-edit/:id" element={<EditProductForm />} />
              <Route path="/create-product" element={<CreateProductForm />} />
              <Route path="/feedback" element={<Feedback />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </article>
          <aside>
            <h1 className="title">Новинки</h1>
            <Banner />
            <Banner />
            <Banner />
          </aside>
        </main>

        <footer>
          <div className="tg-contact">
            Контакты: @Klimious <FaTelegram className="tg-icon" />
          </div>
          Создатель сайта: Даниил Климентов
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;
