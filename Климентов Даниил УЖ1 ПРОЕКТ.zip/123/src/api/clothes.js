import axios from "axios";

const API_BASE_URL = "https://api.escuelajs.co/api/v1";

export const fetchClothesData = async () => {
  try {
    const categoryIds = [1, 4];
    const productPromises = categoryIds.map((id) =>
      axios.get(`${API_BASE_URL}/products`, { params: { categoryId: id } })
    );

    const responses = await Promise.all(productPromises);
    const products = responses.flatMap((response) => response.data);

    const cleanedProducts = products.map((clothe) => ({
      ...clothe,
      images: clothe.images.map((url) => url.replace(/["[\]']/g, "")),
    }));

    return cleanedProducts.filter(
      (clothe) =>
        clothe.category.name === "Clothes" || clothe.category.name === "Shoes"
    );
  } catch (error) {
    throw new Error(`Ошибка при получении данных о продуктах ${error}`);
  }
};

export const fetchClotheData = async (id) => {
  try {
    const { data: clothe } = await axios.get(`${API_BASE_URL}/products/${id}`);
    clothe.images = clothe.images.map((url) => url.replace(/["[\]']/g, ""));
    return clothe;
  } catch (error) {
    throw new Error(`Ошибка при загрузке списка продуктов ${error}`);
  }
};

export const deleteClothe = async (id) => {
  try {
    await axios.delete(`${API_BASE_URL}/products/${id}`);
    return { message: "Продукт удален успешно" };
  } catch (error) {
    throw new Error(`Ошибка при удалении продукта ${error}`);
  }
};

export const updateClothe = async (id, updatedData) => {
  try {
    const { data: updatedProduct } = await axios.put(
      `${API_BASE_URL}/products/${id}`,
      updatedData,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return updatedProduct;
  } catch (error) {
    throw new Error(`Ошибка при редактировании продукта ${error}`);
  }
};

export const createClothe = async (productData) => {
  try {
    const { data: createdProduct } = await axios.post(
      `${API_BASE_URL}/products/`,
      productData,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return createdProduct;
  } catch (error) {
    throw new Error(`Ошибка при создании продукта ${error}`);
  }
};

export const uploadFile = async (fileData) => {
  try {
    const { data } = await axios.post(
      `${API_BASE_URL}/files/upload`,
      fileData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return data;
  } catch (error) {
    throw new Error(`Ошибка при загрузке файла ${error}`);
  }
};
