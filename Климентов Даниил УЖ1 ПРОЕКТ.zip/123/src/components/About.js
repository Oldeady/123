import logo from "../assets/author-photo.jpg";
import "../styles/about.css";
const About = () => {
  return (
    <div className="about-container">
      <h2 className="title">Об авторе</h2>
      <img className="logo" src={logo} alt="logo" loading="lazy"/>
      <p>Даниил Климентов</p>

      <article className="about">
        <p>Имею большой опыт работы с текстами. Помогаю в написании текстов, эссе,
        рефератов студентам и школьникам.</p>
        <b>Достижения</b>
        Победитель областных и региональных соревонований по футболу.
        <p>Входил в топ-50 участников 2-го сезона по направлению "Фронтенд" на платформе CodeRun</p>
      </article>
    </div>
  );
};

export default About;
