import React, { useContext, useState, useEffect, useCallback } from "react";
import { ProductContext } from "../context/ProductProvider";
import "../styles/banner.css";

const Banner = () => {
  const { products, loadProducts } = useContext(ProductContext);
  const [currentProduct, setCurrentProduct] = useState(null);

  const memoizedLoadProducts = useCallback(() => {
    if (!products || products.length === 0) {
      loadProducts();
    }
  }, [products, loadProducts]);

  const getRandomImage = (images) => {
    if (!images || images.length === 0) return null;
    const randomIndex = Math.floor(Math.random() * images.length);
    return images[randomIndex];
  };

  useEffect(() => {
    memoizedLoadProducts();

    if (products && products.length > 0) {
      const getRandomProduct = () => {
        const availableProducts = products.slice(
          0,
          Math.min(5, products.length)
        );
        return availableProducts[
          Math.floor(Math.random() * availableProducts.length)
        ];
      };

      setCurrentProduct(getRandomProduct());

      const intervalId = setInterval(() => {
        setCurrentProduct(getRandomProduct());
      }, 10000);

      return () => clearInterval(intervalId);
    }
  }, [products, memoizedLoadProducts]);

  if (!currentProduct) {
    return <div>Loading banner...</div>;
  }

  return (
    <div className="banner">
      <img
        className="banner-image"
        src={getRandomImage(currentProduct.images) || "placeholder-image-url"}
        alt={currentProduct.name}
      />
      <h3 className="product-title">{currentProduct.name}</h3>
    </div>
  );
};

export default Banner;
