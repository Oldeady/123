import React, { useState } from "react";
import { createClothe } from "../api/clothes";

const CreateProductForm = () => {
  const [formData, setFormData] = useState({
    title: "",
    price: "",
    description: "",
    categoryId: "",
    image: "",
  });
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newProduct = {
        title: formData.title,
        price: parseFloat(formData.price),
        description: formData.description,
        categoryId: parseInt(formData.categoryId),
        images: JSON.stringify([formData.image]),
      };
      await createClothe(newProduct);
      setMessage("Продукт успешно создан!");
    } catch (error) {
      setMessage("Ошибка при создании продукта.");
    }
  };

  return (
    <div className="feedback-container">
      <h1>Добавить товар</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Название продукта</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="price">Цена</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="description">Описание</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="categoryId">Категория (ID)</label>
          <input
            type="number"
            name="categoryId"
            value={formData.categoryId}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="image">Ссылка на изображение</label>
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Создать продукт</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default CreateProductForm;