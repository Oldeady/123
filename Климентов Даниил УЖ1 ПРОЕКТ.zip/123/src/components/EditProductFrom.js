import React, { useEffect, useState } from "react";
import { updateClothe, fetchClotheData, uploadFile } from "../api/clothes";
import { useParams } from "react-router-dom";
import "../styles/edit-product.css";
import Loader from "./Loader";

const EditProductForm = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({
    title: "",
    price: "",
    description: "",
    categoryId: "",
    image: "",
  });
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const product = await fetchClotheData(id);
        setFormData({
          title: product.title,
          price: product.price,
          description: product.description,
          categoryId: product.categoryId,
          image: product.images[0] || "",
        });
        setLoading(false);
      } catch (error) {
        setMessage("Ошибка при загрузке данных продукта.");
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let imageUrl = formData.image;

      if (file) {
        const fileData = new FormData();
        fileData.append("file", file);

        const response = await uploadFile(fileData);
        imageUrl = response.location;
      }

      const updatedProduct = {
        title: formData.title,
        price: parseFloat(formData.price),
        description: formData.description,
        categoryId: parseInt(formData.categoryId),
        images: [imageUrl],
      };

      await updateClothe(id, updatedProduct);
      setMessage("Продукт успешно обновлен!");
    } catch (error) {
      setMessage("Ошибка при обновлении продукта.");
    }
  };

  if (loading) {
    return <Loader />;
  }

  return (
    <div className="feedback-container">
      <h1>Редактировать</h1>
      <form onSubmit={handleSubmit} className="edit-product-form">
        <div className="form-group">
          <label htmlFor="title">Название продукта</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label htmlFor="price">Цена</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label htmlFor="description">Описание</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label htmlFor="categoryId">Категория (ID)</label>
          <input
            type="number"
            name="categoryId"
            value={formData.categoryId}
            onChange={handleChange}
            required
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label htmlFor="image">Текущая ссылка на изображение</label>
          <input
            type="text"
            name="image"
            value={formData.image}
            readOnly
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label htmlFor="file">Загрузить новое изображение</label>
          <input
            type="file"
            name="file"
            onChange={handleFileChange}
            className="form-control"
          />
        </div>
        <button type="submit" className="btn-submit">
          Обновить продукт
        </button>
      </form>
      {message && <p className="message">{message}</p>}
    </div>
  );
};

export default EditProductForm;
