import React, { useState } from "react";
import { FaPhone, FaWhatsapp, FaTelegram } from "react-icons/fa";
import "../styles/feedback.css";
import emailjs from "@emailjs/browser";

function Feedback() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    emailjs
      .send(
        "service_9wlkh7l",
        "template_oxpuikz",
        {
          from_name: formData.name,
          from_email: formData.email,
          message: formData.message,
        },
        "mROJwv5pt2QqoxcJx"
      )
      .then(
        () => {
          setSuccessMessage("Ваше сообщение успешно отправлено!");
          setErrorMessage("");
          setFormData({
            name: "",
            email: "",
            message: "",
          });
        },
        (err) => {
          setErrorMessage("При отправке сообщения произошла ошибка.");
          setSuccessMessage("");
        }
      );
  };

  return (
    <div className="feedback-container">
      <h1>Обратная связь</h1>
      <p>
        <FaPhone /> Телефон: +7 918 852 1886
      </p>
      <p>
        <FaWhatsapp /> WhatsApp: +7 918 852 1886
      </p>
      <p>
        <FaTelegram /> Telegram: @Klimious
      </p>

      <form onSubmit={handleSubmit}>
        <div className="form-item">
          <label>Имя:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-item">
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-item">
          <label>Сообщение:</label>
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Отправить</button>
      </form>

      {successMessage && <p className="success-message">{successMessage}</p>}
      {errorMessage && <p className="error-message">{errorMessage}</p>}
    </div>
  );
}

export default Feedback;
