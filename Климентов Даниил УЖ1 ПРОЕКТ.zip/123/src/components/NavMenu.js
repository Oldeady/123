import React from "react";
import { Link, useLocation } from "react-router-dom";
import "../styles/nav-menu.css";

const NavMenu = () => {
  const location = useLocation();

  const routes = {
    "/news": "Новости",
    "/about": "Об авторе",
    "/products": "Продукты и услуги",
    "/product-table": "Таблица товаров",
    "/create-product": "Добавить товар",
    "/feedback": "Обратная связь",
  };

  return (
    <nav className="nav">
      <ul className="list">
        {Object.entries(routes).map(([path, label]) => (
          <li className="item" key={path}>
            <Link
              to={path}
              className={`link ${location.pathname === path ? "active" : ""}`}
            >
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default NavMenu;
