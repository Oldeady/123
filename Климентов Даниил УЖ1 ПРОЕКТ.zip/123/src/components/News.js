import React, { useEffect, useState } from "react";
import Loader from "./Loader";
import ProductPreview from "./ProductPreview";
import "../styles/product-list.css";
import "../styles/news.css";
import { fetchClothesData } from "../api/clothes";

const News = () => {
  const [clothingProducts, setClothingProducts] = useState([]);
  const [shoesProducts, setShoesProducts] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [allProducts, setAllProducts] = useState([]);

  const initialLoadCount = 10;
  const loadIncrement = 5;

  const loadProducts = async () => {
    try {
      const products = await fetchClothesData();
      setAllProducts(products);
      const currentDate = new Date();
      const thirtyDaysAgo = new Date(currentDate);
      thirtyDaysAgo.setDate(currentDate.getDate() - 14);

      const clothing = products.filter(
        (product) => product.category?.name === "Clothes"
      );
      const shoes = products.filter(
        (product) => product.category?.name === "Shoes"
      );
      const newItems = products.filter(
        (product) => new Date(product.creationAt) >= thirtyDaysAgo
      );

      setClothingProducts(clothing.slice(0, initialLoadCount));
      setShoesProducts(shoes.slice(0, initialLoadCount));
      setNewArrivals(newItems.slice(0, 5));
    } catch (err) {
      setError("Ошибка загрузки данных");
    } finally {
      setLoading(false);
    }
  };

  const loadMoreProducts = () => {
    setClothingProducts((prev) =>
      allProducts
        .filter((product) => product.category?.name === "Clothes")
        .slice(0, prev.length + loadIncrement)
    );
    setShoesProducts((prev) =>
      allProducts
        .filter((product) => product.category?.name === "Shoes")
        .slice(0, prev.length + loadIncrement)
    );
    setNewArrivals((prev) =>
      allProducts
        .filter(
          (product) =>
            new Date(product.creationAt) >=
            new Date(new Date().setDate(new Date().getDate() - 14))
        )
        .slice(0, prev.length + loadIncrement)
    );
  };

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (!loading && !error) {
      const interval = setInterval(() => {
        loadMoreProducts();
      }, 40000);

      return () => clearInterval(interval);
    }
  }, [loading, error]);

  if (loading) {
    return <Loader />;
  }

  if (error) {
    return <div className="error-message">Ошибка загрузки данных: {error}</div>;
  }

  return (
    <div className="news-page">
      <div>
        <h2>Хиты продаж за последние 2 недели</h2>
        <div className="products-container">
          {newArrivals.length > 0 ? (
            newArrivals.map((product) => (
              <ProductPreview product={product} key={product.id} />
            ))
          ) : (
            <div>Нет новых товаров.</div>
          )}
        </div>
        <h2>Одежда</h2>
        <div className="products-container">
          {clothingProducts.length > 0 ? (
            clothingProducts.map((product) => (
              <ProductPreview product={product} key={product.id} />
            ))
          ) : (
            <div>Нет товаров в категории "Одежда".</div>
          )}
        </div>
        
        <h2>Обувь</h2>
        <div className="products-container">
          {shoesProducts.length > 0 ? (
            shoesProducts.map((product) => (
              <ProductPreview product={product} key={product.id} />
            ))
          ) : (
            <div>Нет товаров в категории "Обувь".</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default News;
