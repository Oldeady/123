import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Loader from "./Loader";
import { fetchClotheData } from "../api/clothes";
import "../styles/product.css";
import { sliderSettings } from "../configs/slider-settings";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export const Product = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;

    async function loadProduct() {
      setLoading(true);
      setError(null);
      try {
        const fetchedProduct = await fetchClotheData(id);
        if (isMounted) {
          setProduct(fetchedProduct);
        }
      } catch (err) {
        if (isMounted) {
          setError(err.message);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    loadProduct();

    return () => {
      isMounted = false;
    };
  }, [id]);

  if (loading) {
    return <Loader />;
  }

  if (error) {
    return <div className="error-message">Ошибка загрузки данных: {error}</div>;
  }

  if (!product) {
    return <div>Loading product...</div>;
  }

  const emptyImage =
    "https://img2.freepng.ru/20180330/kje/kisspng-towel-clothes-hanger-computer-icons-hanger-5abdc16889aa79.3749359115223852565639.jpg";

  return (
    <div className="product-container">
      <Slider {...sliderSettings} className="slider">
        {product.images && product.images.length > 0 ? (
          product.images.map((image, index) => (
            <div key={index}>
              <img
                className="image"
                src={image}
                alt={`${product.title}-${index}`}
                loading="lazy"
              />
            </div>
          ))
        ) : (
          <div>
            <img
              className="image"
              src={emptyImage}
              alt="Картинка недоступна"
              loading="lazy"
            />
          </div>
        )}
      </Slider>
      <div className="product-info">
        <h1 className="title">{product.title} </h1>
        <h3 className="description">{product.description}</h3>
        <span className="price">{product.price} $</span>
      </div>
    </div>
  );
};
