import React, { useEffect, useState } from "react";
import Loader from "./Loader";
import ProductPreview from "./ProductPreview";
import "../styles/product-list.css";
import { fetchClothesData } from "../api/clothes";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const data = await fetchClothesData();
      setProducts(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  if (loading) {
    return <Loader />;
  }

  if (error) {
    return <div className="error-message">Ошибка загрузки данных: {error}</div>;
  }

  return (
    <div className="products-container">
      {products.map((product) => (
        <ProductPreview product={product} key={product.id} />
      ))}
    </div>
  );
};

export default ProductList;
