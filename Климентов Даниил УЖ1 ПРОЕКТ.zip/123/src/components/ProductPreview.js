import React from "react";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import { sliderSettings } from "../configs/slider-settings";
import "../styles/product-preview.css";

const ProductPreview = ({ product }) => {
  const navigate = useNavigate();

  const emptyImage =
    "https://img2.freepng.ru/20180330/kje/kisspng-towel-clothes-hanger-computer-icons-hanger-5abdc16889aa79.3749359115223852565639.jpg";

  if (!product) {
    return <div className="error-message">Продукт не найден</div>;
  }

  const navigateToProduct = () => {
    navigate(`/product/${product.id}`);
  };

  return (
    <div className="product-preview-container">
      <Slider {...sliderSettings} className="slider">
        {product.images && product.images.length > 0 ? (
          product.images.map((image, index) => (
            <div key={index}>
              <img
                className="image"
                src={image}
                alt={`${product.title}-${index}`}
              />
            </div>
          ))
        ) : (
          <div>
            <img
              className="image"
              src={emptyImage}
              alt="Картинка недоступна"
              loading="lazy"
            />
          </div>
        )}
      </Slider>
      <h3 className="title">{product.title}</h3>
      <p className="description">{product.description}</p>
      <div className="info">
        <button onClick={navigateToProduct} className="info-button">
          Подробнее
        </button>
        <p className="price">{product.price} $</p>
      </div>
    </div>
  );
};

ProductPreview.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.number.isRequired,
    images: PropTypes.arrayOf(PropTypes.string),
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
  }),
};

export default ProductPreview;
