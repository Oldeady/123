import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { FaEdit, FaTrashAlt } from "react-icons/fa";
import "../styles/product-table.css";
import Loader from "./Loader";
import { fetchClothesData } from "../api/clothes";

const ProductTable = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortField, setSortField] = useState("");
  const [sortOrder, setSortOrder] = useState("asc"); // сортировка по возрастсанию / убыванию

  useEffect(() => {
    fetchClothesData()
      .then((response) => {
        setLoading(false);
        setProducts(response);
      })
      .catch((error) => {
        console.error("Ошибка при загрузке данных: ", error);
      });
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Вы уверены, что хотите удалить продукт?")) {
      axios
        .delete(`https://api.escuelajs.co/api/v1/products/${id}`)
        .then(() => {
          setProducts(products.filter((product) => product.id !== id));
        })
        .catch((error) => {
          console.error("Ошибка при удалении: ", error);
        });
    }
  };

  const handleSort = (field) => {
    const order = sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(order);
  };

  let sortedProducts;
  if (products.length) {
    sortedProducts = [...products].sort((a, b) => {
      if (!sortField) return 0;
      let valueA, valueB;

      if (sortField === "category") {
        valueA = a.category?.name || "Без категории";
        valueB = b.category?.name || "Без категории";
      } else if (sortField === "updatedAt") {
        valueA = new Date(a[sortField]);
        valueB = new Date(b[sortField]);
      } else {
        valueA = a[sortField];
        valueB = b[sortField];
      }

      if (valueA < valueB) return sortOrder === "asc" ? -1 : 1;
      if (valueA > valueB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }
  if (loading) {
    return <Loader />;
  }
  return (
    <div className="product-table-container">
      <table className="product-table">
        <thead>
          <tr>
            <th onClick={() => handleSort("id")} className="id">
              ID {sortField === "id" && (sortOrder === "asc" ? "▲" : "▼")}
            </th>
            <th onClick={() => handleSort("title")}>
              Название{" "}
              {sortField === "title" && (sortOrder === "asc" ? "▲" : "▼")}
            </th>
            <th onClick={() => handleSort("price")}>
              Цена {sortField === "price" && (sortOrder === "asc" ? "▲" : "▼")}
            </th>
            <th onClick={() => handleSort("category")}>
              Категория{" "}
              {sortField === "category" && (sortOrder === "asc" ? "▲" : "▼")}
            </th>
            <th onClick={() => handleSort("updatedAt")}>
              Дата
              {sortField === "updatedAt" && (sortOrder === "asc" ? "▲" : "▼")}
            </th>
            <th className="actions">Действия</th>
          </tr>
        </thead>
        <tbody>
          {sortedProducts.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.title}</td>
              <td>${product.price}</td>
              <td>
                {product.category ? product.category.name : "Без категории"}
              </td>
              <td>
                {new Date(product.updatedAt).toLocaleDateString() + " " +
                  new Date(product.updatedAt).toLocaleTimeString()}
              </td>
              <td className="actions">
                <Link
                  to={`/product-edit/${product.id}`}
                  className="edit-button"
                >
                  <FaEdit />
                </Link>
                <button
                  className="delete-button"
                  onClick={() => handleDelete(product.id)}
                >
                  <FaTrashAlt />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductTable;
