import React, { createContext, useState } from "react";
import { fetchClotheData, fetchClothesData } from "../api/clothes";

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [currentProduct, setCurrentProduct] = useState(undefined);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function loadProducts() {
    setLoading(true);
    setError(null); 

    try {
      const fetchedProducts = await fetchClothesData();
      setProducts(fetchedProducts);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false); 
    }
  }

  async function loadProduct(id) {
    setLoading(true);
    setError(null);

    try {
      const fetchedProduct = await fetchClotheData(id);
      setCurrentProduct(fetchedProduct);
    } catch (err) {
      setError(err.message);
      setCurrentProduct(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ProductContext.Provider
      value={{
        products,
        currentProduct,
        loadProducts,
        loadProduct,
        loading,
        error,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};
